package Exceptions;

public class DifferentSizesMatException extends Exception{

    public DifferentSizesMatException() {
        super("Los tamanos de los Mat son diferentes o no existen");
    }
    
}
