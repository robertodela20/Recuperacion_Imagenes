package Exceptions;

public class DeletingDirectoryException extends Exception {
    public DeletingDirectoryException() {
        super("Error eliminando el directorio");
    }
}
