package Controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

/**
 * FXML Controller class para la ventana de ayuda.
 *
 * @author Stanislav
 */
public class ManualController implements Initializable {
    private Stage stage;


    
    
    public Stage getStage() {
        return stage;
        // TODO
    }    

    /**
     * Initializes the controller class.
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
