package Controlador;

import Exceptions.FileNotExistsException;
import Exceptions.MatNotExistsFileException;
import Exceptions.NoSenseMatArrayListException;
import Exceptions.TypeNotExistsException;
import Modelo.DescriptorCoocurrencia;
import Modelo.FachadaModelo;
import Modelo.GuardadoDescriptoresColor;
import Modelo.CalculoColor;
import Modelo.Imagen;
import Modelo.TiposHistogramaLAB;
import Modelo.Workspace;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.opencv.core.Mat;

/**
 * FXML Controller class del panel de visualización/extracción de descriptores.
 *
 * @author Stanislav
 */
public class ExtraccionController implements Initializable {
    private Stage stage;
    private FachadaModelo modelo;
    private Imagen imagen; //Imagen cuyos descriptores se están viendo/extrayendo
    private String modo; //Modo de extracción seleccionado
    private Workspace seleccion;
    
    @FXML
    private TreeView treeView;
    
    @FXML
    private ScrollPane scrollPane;

    @FXML 
    private Button extraerBtn;

    public Workspace getSeleccion() {
        return seleccion;
    }

    public void setSeleccion(Workspace seleccion) {
        this.seleccion = seleccion;
    }  
    
    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public FachadaModelo getModelo() {
        return modelo;
    }

    public void setModelo(FachadaModelo modelo) {
        this.modelo = modelo;
    }

    public Imagen getImagen() {
        return imagen;
    }

    public void setImagen(Imagen imagen) {
        this.imagen = imagen;
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Establecer el treeView
        TreeItem rootItem = new TreeItem("Opciones");
        rootItem.setExpanded(true);
        rootItem.getChildren().add(new TreeItem("Textura"));
        rootItem.getChildren().add(new TreeItem("Color"));
        //Añadir aquí otras categorías
        treeView.setRoot(rootItem);
        // Listener para el tree
        treeView.getSelectionModel().selectedItemProperty().addListener( 
        new ChangeListener() {

            @Override
            public void changed(ObservableValue observable, Object oldValue,
                    Object newValue) {

                TreeItem<String> selectedItem = (TreeItem<String>) newValue;
                System.out.println("Selected Text : " + selectedItem.getValue());
                if(!selectedItem.getValue().equals("Opciones")){
                    extraerBtn.setDisable(false);
                    //Crear la vista de detalles, cargando los datos desde el descriptor de este tipo desde el propio objeto de Imagen. El propio objeto únicamente se crea al extraer un nuevo descriptor o al abrir el programa en init, donde se leen los archivos de descriptores existentes!
                    if(selectedItem.getValue().equals("Textura")){
                        modo = "Textura";
                        //Vista de coocurrencia si existe
                        DescriptorCoocurrencia descriptor = null;
                        for(int i = 0; i< imagen.getDescriptores().size(); i++){
                            if(imagen.getDescriptores().get(i) instanceof DescriptorCoocurrencia){
                                descriptor = (DescriptorCoocurrencia) imagen.getDescriptores().get(i);
                            }
                        }
                        if(descriptor == null){
                            //Mensaje de descriptor inexistente
                            Pane pane = new Pane();
                            Label label = new Label("No existen descriptores de coocurrencia para esta imagen. Utiliza el botón de \"Extraer\" para obtenerlos.");
                            pane.getChildren().add(label);
                            scrollPane.setContent(pane);
                        }else{
                            //Se muestran todos los detalles del descriptor seleciconado
                            establecerDetallesCoocurrencia();
                        }
                            
                        
                        
                    }
                    else if(selectedItem.getValue().equals("Color")){
                        modo = "Color";
                        //Vista de coocurrencia si existe
                        
                    }
                }
                
            }
        });
    }    
    
    //métodods de apoyo para actualizar la vista de detalles
    private void establecerDetallesCoocurrencia(){
        DescriptorCoocurrencia descriptor = null;
        for(int i = 0; i< imagen.getDescriptores().size(); i++){
            if(imagen.getDescriptores().get(i) instanceof DescriptorCoocurrencia){
                descriptor = (DescriptorCoocurrencia) imagen.getDescriptores().get(i);
            }
        }
        if(descriptor != null){
            //extraerBtn.setText("Actualizar");
            GridPane gp = new GridPane();
            gp.setGridLinesVisible(true);
            //Se introducen todos los datos del descriptor en la tabla
            Label c1 = new Label("0º");
            Label c2 = new Label("45º");
            Label c3 = new Label("90º");
            Label c4 = new Label("135º");
            Label c5 = new Label("Media");
            Label c6 = new Label("Rango (max-min)");
            c1.setPadding(new Insets(2,2,2,2));
            c2.setPadding(new Insets(2,2,2,2));
            c3.setPadding(new Insets(2,2,2,2));
            c4.setPadding(new Insets(2,2,2,2));
            c5.setPadding(new Insets(2,2,2,2));
            c6.setPadding(new Insets(2,2,2,2));
            
            gp.add(c1, 1, 0);
            gp.add(c2, 2, 0);
            gp.add(c3, 3, 0);
            gp.add(c4, 4, 0);
            gp.add(c5, 5, 0);
            gp.add(c6, 6, 0);
            
            Label r1 = new Label("Energía");
            Label r2 = new Label("Inercia");
            Label r3 = new Label("Correlación");
            Label r4 = new Label("IDM");
            Label r5 = new Label("Entropía");
            r1.setPadding(new Insets(2,2,2,2));
            r2.setPadding(new Insets(2,2,2,2));
            r3.setPadding(new Insets(2,2,2,2));
            r4.setPadding(new Insets(2,2,2,2));
            r5.setPadding(new Insets(2,2,2,2));
            
            gp.add(r1, 0, 1);
            gp.add(r2, 0, 2);
            gp.add(r3, 0, 3);
            gp.add(r4, 0, 4);
            gp.add(r5, 0, 5);
            
            float[][] res = descriptor.devolverMatriz();
            int row = 1;
            int col = 1;
            for(int i = 0; i < 5; i++){
                for(int j = 0; j<6; j++){
                    //Label temp = new Label(Float.toString(res[i][j]));
                    TextField temp = new TextField(Float.toString(res[i][j]));
                    temp.setEditable(false);
                    temp.setPadding(new Insets(2,2,2,2));
                    gp.add(temp, col, row);
                    col++;
                }
                row++;
                col = 1;
            }
            gp.setPadding(new Insets(50,10,10,10));
            Pane pane = new Pane();
            Label dist = new Label("Distancia = " + descriptor.getDistancia());
            dist.setPadding(new Insets(10,10,10,10));
           
            pane.getChildren().add(dist);
            pane.getChildren().add(gp);
            scrollPane.setContent(pane);
        }
    }
    
    //métodods de apoyo para actualizar la vista de detalles
    private Mat extraerDescriptorColor(int caso) throws IOException, NoSenseMatArrayListException, TypeNotExistsException, FileNotExistsException{
        Mat hist = null;
        GuardadoDescriptoresColor guardadoDescriptores = new GuardadoDescriptoresColor();
        File file = new File(seleccion.getPath(), imagen.getNombre());
        String pathImagen = file.getPath();
        //String pathImagen = seleccion.getPath()+ "/" +imagen.getNombre();
        CalculoColor calculo = new CalculoColor();
        switch (caso) {
            case 0:     //componente L
                try {   //imagen 1
                    hist = guardadoDescriptores.getHistogram(pathImagen, seleccion.getPath(), TiposHistogramaLAB.L);       //intentamos recuperarlo del fichero de descriptores
                } catch (MatNotExistsFileException ex) {
                    hist = calculo.L_comp_LAB(pathImagen);    //calculamos el descriptor
                    System.out.println(pathImagen + "OOOOOOOOOOOOOOOOOOOOOOOOOOOOO ");
                    System.out.println(seleccion.getPath() + "OOOOOOOOOOOOOOOOOOOOOOOOOOOOO ");
                    //System.out.println(hist + "OOOOOOOOOOOOOOOOOOOOOOOOOOOOO ");
                    guardadoDescriptores.saveHistogram(pathImagen, "", hist, TiposHistogramaLAB.L);       //guardamos el descriptor
                }
                break;
            case 1:         //componente A
                try {   //imagen 1
                    hist = guardadoDescriptores.getHistogram(pathImagen, seleccion.getPath(), TiposHistogramaLAB.A);       //intentamos recuperarlo del fichero de descriptores
                } catch (MatNotExistsFileException ex) {
                    hist = calculo.A_comp_LAB(pathImagen);    //calculamos el descriptor
                    guardadoDescriptores.saveHistogram(pathImagen, "", hist, TiposHistogramaLAB.A);       //guardamos el descriptor
                }
                break;
            case 2:         //componente B
                try {   //imagen 1
                    hist = guardadoDescriptores.getHistogram(pathImagen, seleccion.getPath(), TiposHistogramaLAB.B);       //intentamos recuperarlo del fichero de descriptores
                } catch (MatNotExistsFileException ex) {
                    hist = calculo.B_comp_LAB(pathImagen);    //calculamos el descriptor
                    guardadoDescriptores.saveHistogram(pathImagen, "", hist, TiposHistogramaLAB.B);       //guardamos el descriptor
                }
                break;
        }
        return hist;
    }
    
    private void establecerDetallesColor(Mat histL, Mat histA, Mat histB){
        //extraerBtn.setText("Actualizar");
        GridPane gp = new GridPane();
        gp.setGridLinesVisible(true);
        //Se introducen todos los datos del descriptor en la tabla
        Label c1 = new Label("L");
        Label c2 = new Label("A");
        Label c3 = new Label("B");
        c1.setPadding(new Insets(2,2,2,2));
        c2.setPadding(new Insets(2,2,2,2));
        c3.setPadding(new Insets(2,2,2,2));
        
        gp.add(c1, 0, 0);
        gp.add(c2, 1, 0);
        gp.add(c3, 2, 0);

        int row = 1;
        double a[];
        for (int i=0; i<histL.height(); i++) {
            for (int j=0; j<histL.width(); j++) {
                a = histL.get(i, j);
                TextField temp = new TextField(String.valueOf(a[0]));
                temp.setEditable(false);
                temp.setPadding(new Insets(2,2,2,2));
                gp.add(temp, 0, row);
                row++;
            }
        }
        row = 1;
        for (int i=0; i<histA.height(); i++) {
            for (int j=0; j<histA.width(); j++) {
                a = histA.get(i, j);
                TextField temp = new TextField(String.valueOf(a[0]));
                temp.setEditable(false);
                temp.setPadding(new Insets(2,2,2,2));
                gp.add(temp, 1, row);
                row++;
            }
        }
        row = 1;
        for (int i=0; i<histB.height(); i++) {
            for (int j=0; j<histB.width(); j++) {
                a = histB.get(i, j);
                TextField temp = new TextField(String.valueOf(a[0]));
                temp.setEditable(false);
                temp.setPadding(new Insets(2,2,2,2));
                gp.add(temp, 2, row);
                row++;
            }
        }
        gp.setPadding(new Insets(50,10,10,10));
        Pane pane = new Pane();
        pane.getChildren().add(gp);
        scrollPane.setContent(pane);
    }
    
    @FXML 
    public void extraer(ActionEvent event){
        //Al terminar de extraer, refresca la vista seleccionada
        treeView.setDisable(true);
        if(modo.equals("Textura")){
            System.out.println("Extrayendo Textura...");
            seleccion.extraerDescriptorCoocurrencia(imagen.getNombre());
            this.establecerDetallesCoocurrencia();
        }
        else if(modo.equals("Color")){
            System.out.println("Extrayendo Color...");
            Mat histL=null;
            Mat histA=null;
            Mat histB=null;
            for (int i=0; i<3; i++) {
                try {
                    System.out.println ("UUUUUUUNA-----------------------------:" + i);
                        if(i==0) histL=extraerDescriptorColor(i);
                        else if(i==1) histA=extraerDescriptorColor(i);
                        else if (i==2) histB=extraerDescriptorColor(i);
                }
                catch (TypeNotExistsException ex) {
                    Logger.getLogger(ExtraccionController.class.getName()).log(Level.SEVERE, null, ex);
                } 
                catch (FileNotExistsException ex) {
                    Logger.getLogger(ExtraccionController.class.getName()).log(Level.SEVERE, null, ex);
                }
                catch (IOException ex) {
                    Logger.getLogger(ExtraccionController.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSenseMatArrayListException ex) {
                    Logger.getLogger(ExtraccionController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            this.establecerDetallesColor(histL,histA,histB);
        }  
        treeView.setDisable(false);
    }
    
    @FXML 
    public void cerrar(ActionEvent event){
        stage.close();
    }
}
