package Controlador;

import Modelo.FachadaModelo;
import Modelo.Workspace;
import java.awt.image.BufferedImage;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image; 
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.shape.Rectangle;
import javax.imageio.ImageIO;

public class ProcesadoLocalController {

    private FachadaModelo modelo;
    private Stage stage;
    private Stage stagePadre;
    private Workspace sel;
    private HomeControlador controllerPadre;
    private String imagenUrl;
    
    private Image photo;
    private String nameFile;
    private Color color1 = Color.rgb(255, 255, 255);
    private Color color2 = Color.rgb(0, 0, 0);
    private float clipX = 0;
    private float clipY = 0;
    private float clipWidth;
    private float clipHeight;
    private int x1 = 0;
    private int y1 = 0;
    private int x2 = 0;
    private int y2 = 0;
    private boolean band = true;
    private int count = 0;
    
    private ContextMenu contextMenu = new ContextMenu();
    
    @FXML
    private ImageView imageView; // Nuevo nodo para mostrar la imagen

    private Rectangle selectionRect;

    @FXML
    private StackPane stackPane; // Este es tu contenedor principal en el FXML

    public ProcesadoLocalController(String imagenUrl, String nombre) {
        this.imagenUrl = imagenUrl;
        this.nameFile = nombre;
    }
    
    @FXML
    public void initialize() {
        if (stackPane != null) {
            stackPane.setOnMouseDragged(this::mouseDragged);
            stackPane.setOnMousePressed(this::mousePressed);
            stackPane.setOnMouseClicked(this::mouseClicked);
            stackPane.setOnMouseReleased(this::mouseReleased);
        }

        if (this.imagenUrl != null) {
            File file = new File(this.imagenUrl);
            if (file.exists()) {
                photo = new Image(file.toURI().toString());
                // Configurar la imagen en el ImageView
                imageView.setImage(photo);
                updateUI();
            } else {
                System.out.println("El archivo de imagen no existe: " + imagenUrl);
            }
        }
        Timeline colorChangeTimeline = new Timeline(
                new KeyFrame(Duration.millis(350), event -> {
                    color1 = (band) ? Color.rgb(255, 255, 255) : Color.rgb(0, 0, 0);
                    color2 = (band) ? Color.rgb(0, 0, 0) : Color.rgb(255, 255, 255);
                    band = !band;
                    updateUI();
                })
        );
        colorChangeTimeline.setCycleCount(Timeline.INDEFINITE);
        colorChangeTimeline.play();

        MenuItem saveItem = new MenuItem("Guardar imagen");
        saveItem.setOnAction(event -> {
            try {
                saveImage();
            } catch (IOException ex) {
                Logger.getLogger(ProcesadoLocalController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        contextMenu.getItems().add(saveItem);
        
        selectionRect = new Rectangle(0, 0, 0, 0);
        selectionRect.setFill(null);
        selectionRect.setStroke(color2);
        stackPane.getChildren().add(selectionRect);
    }

    private void updateUI() {
        if (selectionRect != null) {
            selectionRect.setX(Math.min(x1, x2));
            selectionRect.setY(Math.min(y1, y2));
            selectionRect.setWidth(Math.abs(x2 - x1));
            selectionRect.setHeight(Math.abs(y2 - y1));

            if (!stackPane.getChildren().contains(imageView)) {
                stackPane.getChildren().add(imageView);
            }
        }
    }

    private void saveImage() throws IOException {
    try {
        double imageWidth = photo.getWidth();
        double imageHeight = photo.getHeight();
        double viewWidth = imageView.getBoundsInParent().getWidth();
        double viewHeight = imageView.getBoundsInParent().getHeight();

        // Calcular el factor de escala entre la imagen original y el ImageView
        double scaleX = imageWidth / viewWidth;
        double scaleY = imageHeight / viewHeight;

        // Ajustar las coordenadas de recorte con el factor de escala
        int x = (int) ((clipX - imageView.getLayoutX()) * scaleX);
        int y = (int) ((clipY - imageView.getLayoutY()) * scaleY);
        int width = (int) (clipWidth * scaleX);
        int height = (int) (clipHeight * scaleY);

        // Asegurarse de que las coordenadas y dimensiones del recorte estén dentro de los límites de la imagen
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x + width > imageWidth) width = (int) imageWidth - x;
        if (y + height > imageHeight) height = (int) imageHeight - y;

        System.out.println("Los valores ajustados son: " + x + " ," + y + " ," + width + " ," + height);

        // Crear una nueva imagen recortada
        WritableImage writableImage = new WritableImage(photo.getPixelReader(), x, y, width, height);
        BufferedImage croppedImage = SwingFXUtils.fromFXImage(writableImage, null);
        if (croppedImage == null) {
            System.out.println("La imagen recortada es nula. No se puede guardar.");
        }

        // Guardar la imagen recortada
        count++;
        String nombreSinExtension = imagenUrl;
        int lastIndex = nombreSinExtension.lastIndexOf('.');
        if (lastIndex > 0) {
            nombreSinExtension = nombreSinExtension.substring(0, lastIndex);
        }
        File imageFolder = new File(nombreSinExtension);
        if (!imageFolder.exists()) {
            imageFolder.mkdirs();
        }
        String nombre = this.nameFile.split("\\.")[0];

        File outputFile = new File(imageFolder.getAbsolutePath() + "\\" + "recorte" + "_" + count + "_" + nombre + ".jpg");
        if (croppedImage != null) {
            croppedImage.flush();
            ImageIO.write(croppedImage, "png", outputFile);
            System.out.println("Tipo de imagen recortada: " + croppedImage.getType());
            System.out.println("Ancho de imagen recortada: " + croppedImage.getWidth());
            System.out.println("Altura de imagen recortada: " + croppedImage.getHeight());
            System.out.println("Imagen guardada en: " + outputFile.getAbsolutePath());
        } else {
            System.out.println("La imagen recortada es nula. No se puede guardar.");
        }
        if (outputFile.exists() && outputFile.length() > 0) {
            System.out.println("Imagen guardada en: " + outputFile.getAbsolutePath());
            sel.anhadirImagen(outputFile);
            //this.sel.anhadirImagen(outputFile);
        } else {
            System.out.println("La imagen no se guardó correctamente.");
        }
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println("Error al guardar la imagen: " + e.getMessage());
    }
}


    private void mouseDragged(MouseEvent e) {
        x2 = (int) e.getX();
        y2 = (int) e.getY();
        updateUI();
    }

    private void mousePressed(MouseEvent e) {
        if (e.getButton() == MouseButton.PRIMARY) {
            x1 = (int) e.getX();
            y1 = (int) e.getY();
        }
    }

    private void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseButton.SECONDARY) {
            if (clipWidth > 0 && clipHeight > 0) {
                try {
                    saveImage();
                } catch (IOException ex) {
                    Logger.getLogger(ProcesadoLocalController.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                System.out.println("No hay un rectángulo de selección para guardar.");
            }
        }
    }

    private void mouseReleased(MouseEvent e) {
        clipX = Math.min(x1, x2);
        clipY = Math.min(y1, y2);
        clipWidth = Math.abs(x2 - x1);
        clipHeight = Math.abs(y2 - y1);
        updateUI();
    }

    @FXML
    public void cerrar(ActionEvent event) {
        stage.close();
    }

    public FachadaModelo getModelo() {
        return modelo;
    }

    public void setModelo(FachadaModelo modelo) {
        this.modelo = modelo;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Stage getStagePadre() {
        return stagePadre;
    }

    public void setStagePadre(Stage stagePadre) {
        this.stagePadre = stagePadre;
    }

    public Workspace getSel() {
        return sel;
    }

    public void setSel(Workspace sel) {
        this.sel = sel;
    }

    public HomeControlador getControllerPadre() {
        return controllerPadre;
    }

    public void setControllerPadre(HomeControlador controllerPadre) {
        this.controllerPadre = controllerPadre;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }
}
