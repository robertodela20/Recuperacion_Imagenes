package Modelo;

public class Color {
    public static final java.awt.Color colorFondo = new java.awt.Color (0xEEFFFF);
    public static final java.awt.Color colorBoton = new java.awt.Color (0xEEFFFF);
}
