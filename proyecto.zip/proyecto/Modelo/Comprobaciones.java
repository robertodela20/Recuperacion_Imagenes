
package Modelo;


public class Comprobaciones {
    
    
    public boolean comprobarTerminacion (String name) {
        return (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".gif") || name.endsWith(".jpeg") || name.endsWith(".bmp") 
                || name.endsWith(".JPG") || name.endsWith(".JPEG") );
    }
    
    
    

}
